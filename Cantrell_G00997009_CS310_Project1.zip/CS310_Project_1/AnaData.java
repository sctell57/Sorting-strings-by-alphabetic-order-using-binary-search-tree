
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.Iterator;

public class AnaData implements Visitable<AnaData>{

	private String key;
	private GList<String> list;
	private BufferedWriter bw;

	@Override
	public boolean equals(Object obj) {
		
		return this.key.equals(((AnaData) obj).key); // equals method returns 0 -1 or 1
	}

	public void visit() {
		if(this.list.size() > 1) { // if list has more then one element we run iterator
			Iterator<String> str = this.list.iterator();
			
			while(str.hasNext()) {
				try {
					bw.write(str.next()+" ");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			try {
				bw.write("\n");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public GList<String> getList() {
		return list;
	}

	public void setList(GList<String> list) {
		this.list = list;
	}

	public BufferedWriter getBr() {
		return bw;
	}

	public void setBr(BufferedWriter br) {
		this.bw = br;
	}

	public boolean doubleCheck(String words) {
		Iterator<String> str = this.list.iterator();
		
		while(str.hasNext()) {
			if(words.equals(str.next())){
				return true;
			}
		}
		return false;
	}

	@Override
	public int compareTo(AnaData t) {
		// TODO Auto-generated method stub
		return this.key.compareTo(t.key);
	}

}
