import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class Anagram {
	private static String clean(String str) {
		String clean = "";
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) <= 122 && str.charAt(i) >= 97) {
				clean += str.charAt(i);
			}
		}
		return clean;

	}

	private static String alphabetize(String str) {
		char[] arr = str.toCharArray();
		Arrays.sort(arr);
		String sortedStr = "";
		for (int i = 0; i < arr.length; i++) {
			sortedStr += arr[i];

		}
		return sortedStr;
	}

	static public void main(String[] args) {
		if (args.length < 2) {

			throw new IllegalArgumentException(args[0] + " " + "input file" + " " + "output file");

		} else {
			BinTree<AnaData> tree = new BinTree<AnaData>();
			FileReader input = null;
			FileWriter output = null;
			BufferedReader binput = null;
			BufferedWriter boutput = null;
		
			try {
				input = new FileReader(args[0]);
				output = new FileWriter(args[1]);
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(1);
			}
			binput = new BufferedReader(input);
			Scanner scan = new Scanner(binput);
			boutput = new BufferedWriter(output);
			String words = null;
			String key = null;
			while (scan.hasNext()) {
				words = scan.next();
				words = words.toLowerCase();
				words = clean(words);
				if (words != "") {
					key = alphabetize(words);
					AnaData adata = new AnaData();
					adata.setKey(key);
					adata.setList(new GList<String>());
					adata.setBr(boutput);
					AnaData found = tree.find(adata);
					if (found == null) {
						tree.insert(adata);
						adata.getList().addFirst(words);
					} else {
						if (!found.doubleCheck(words))
							found.getList().addFirst(words);

					}
				}
			}
			tree.traverse();

			try {
				binput.close();
				boutput.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

}
