
public class BinTree<T extends Visitable<T>> {
	private GNode<T> root; // assign variable of Node

	private class GNode<T extends Visitable<T>> {
		T data;
		GNode<T> left;
		GNode<T> right;

		public GNode(T value) {
			data = value;
		}
	}

	public boolean insert(T t) {
		if (t == null)
			return false;
		root = insert(t, root);
		return true;
	}

	private GNode<T> insert(T data, GNode<T> t) {
		if (t == null) {
			t = new GNode<T>(data);
		} else if (data.compareTo(t.data) < 0) {
			t.left = insert(data, t.left);
		} else if (data.compareTo(t.data) > 0) {

			t.right = insert(data, t.right);
		}
//		 else {
//		 throw new DuplicateItemException( data.toString( ) ); // Duplicate
//		 }
		return t;
	}

	public T find(T target) {
		if (root == null) {
			return null; // empty tree
		}
		return find(target, root); // start the search
	}

	private T find(T target, GNode<T> p) {
		if (p == null) {
			return null; // not in tree
		}
		if (target.compareTo(p.data) == 0) {
			return p.data; // found the target
		}
		if (target.compareTo(p.data) < 0) {
			return find(target, p.left); // search through left of BST
		}
		return find(target, p.right); // search through right

	}

	public void traverse() {
		preorder(root);
	}

	@SuppressWarnings("unchecked")
	private void preorder(GNode<T> root) {
		if (root != null) {
			((T) root.data).visit();
			preorder(root.left);
			preorder(root.right);
		}
	}

	

}

