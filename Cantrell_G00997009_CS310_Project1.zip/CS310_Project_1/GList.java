import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class GList<T> {
	private GNode<T> cursor = null; // creates a value of the GNode class
	private int size = 0;
	private class GNode<T> {
		T val;
		GNode<T> next = null;

		GNode(T val) {
			this.val = val;
		}
	}

	public int size() {
		return size;
	}
	public void addFirst(T val) {
		GNode<T> newNode = new GNode<T>(val);
		if (cursor == null) {
			cursor = newNode;
			size++;
		} else {
			newNode.next = cursor;
			cursor = newNode;
			size++;
		}
	}

	public Iterator<T> iterator() {
		return new LinkedListIterator();
	}

	private class LinkedListIterator implements Iterator<T> {
		private GNode<T> nextNode;

		public LinkedListIterator() {

		}

		public boolean hasNext() {
			if (nextNode == null && cursor != null) {
				return true;
			}
			return nextNode.next != null;

		}

		public T next() {
			T temp = null;
			if (nextNode == null && cursor != null) {
				nextNode = cursor;
				return cursor.val;
			}
			if (nextNode.next != null) {
				nextNode = nextNode.next;
				temp = nextNode.val;

			}
			else {
				throw new IllegalArgumentException("No more elements");
			}
			return temp;
		}
	}

	public static void main(String[] args) {
//		GList<Integer> numbers = new GList<Integer>();
//		for (int i = 0; i < 10; i++) {
//			numbers.addFirst(i);
//		}
//		Iterator<Integer> it = numbers.iterator();
//		int i = 0;
//		while(i < 10) {
//			System.out.println(it.next());
//			i++;
//		}
//		System.out.println(it.hasNext());
		char []j = {'a','g'};
		System.out.println(j.toString());

	}

}
