public interface Visitable<T>
{
   void visit();
   int compareTo(T t);
}   